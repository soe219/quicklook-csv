QLQuickCSV - Quick Look Extension for CSV/TSV Files
====================================================

INSTALLATION:
1. Drag QLQuickCSV.app to the Applications folder
2. Open QLQuickCSV.app once to register the extension
3. Go to System Settings → Privacy & Security → Extensions → Quick Look
4. Enable "CSV QL Extension"

USAGE:
- Select any .csv or .tsv file in Finder
- Press Space to preview with interactive table

FEATURES:
- Interactive table with sorting & filtering
- Column type detection (text, number, date, boolean)
- Column statistics & distinct value counts
- Multiple views: Table, Markdown, JSON
- Search across all data (Cmd+F)
- Copy as CSV, Markdown, JSON, or SQL
- Dark/Light mode support

SETTINGS:
Open QLQuickCSV.app and go to the Settings tab to customize display options.

Note: This app is ad-hoc signed for local use. You may need to
right-click and select "Open" the first time to bypass Gatekeeper.
